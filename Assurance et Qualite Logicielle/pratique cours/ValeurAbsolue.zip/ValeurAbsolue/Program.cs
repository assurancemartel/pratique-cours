﻿using System;
public class ValeurAbsolue
{
    public static void calculerValeurAbsolue()
    {
        double x = 0;
        Console.WriteLine("Entrez un nombre x = ");
        try
        {
            x = Double.Parse(Console.ReadLine());
            if (x < 0)
                Console.WriteLine("|x| = " + (-x));
            else
                Console.WriteLine("|x| = " + x);
        }
        catch (FormatException f)
        {
            Console.WriteLine( f.Message);
        }
        //catch
        //{
            //Console.WriteLine("Mauvais format");

        //}

    }
    public static void Main()
    {
        ValeurAbsolue valeurAbsolue = new ValeurAbsolue();
        calculerValeurAbsolue();

    }
}

