﻿using System;
public class Concatenation
{
    public static void Main()
    {
        char lettre = 'C';
        int a = 5;
        int b = a + 2;
        bool test = true;
        //int c = a + test;
        string prenom = "Samuel";
        string nom = "Guennach";
        int numeroCours = 25914;
        string str = "Je suis " + prenom + " et j'aime assister au cours assurance qualité logicielle " + numeroCours ;
        //Console.WriteLine(str);
        Console.WriteLine("Je suis {0} et j'assiste au cours numéro {1}", prenom, numeroCours);
        Console.WriteLine($"Je suis {prenom} et j'assiste au cours {numeroCours}");
        string[] mots = { "je", "veux", "finir", "lasession", "avec", "une", "bonne", "réussite" };
        var phraseIllisible = string.Concat(mots);
        //Console.WriteLine(phraseIllisible);
        var phraseLisible = string.Join(" ", mots);
        Console.WriteLine(phraseLisible);
        
        
    }
}
