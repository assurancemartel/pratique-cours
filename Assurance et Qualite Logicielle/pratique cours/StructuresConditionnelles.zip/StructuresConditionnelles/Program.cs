﻿using System;
public class StructuresConditionnelles
{
    public static void Main()
    {
        int age = 20;
        if (age == 18)
        {
            Console.WriteLine("Condition vérifiée");

        }
        else if(age < 18)
        {
            Console.WriteLine("Condition non vérifiée");
        }
        else if (age == 20)
        {
            Console.WriteLine("C'est ok!");

        }
        else if (age > 60)
        {
            Console.WriteLine("Condition insuffisante");
        }
        else
        {
            Console.WriteLine("Nouvel utilisateur");
        }
    }
}

