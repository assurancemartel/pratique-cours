﻿using System;
public class SwitchConditions
{
    public static void Main()
    {
        int age = 0;

        switch (age)
        {
            case 16:
                Console.WriteLine("Mineur");
                break;
            case 20:
                Console.WriteLine("Majeur");
                break;
            case 30:
                Console.WriteLine("Adulte");
                break;
            case 70:
                Console.WriteLine("Retraité");
                break;
            default:
                Console.WriteLine("Utilisateur inconnu");
                break;

        }
    }
}
