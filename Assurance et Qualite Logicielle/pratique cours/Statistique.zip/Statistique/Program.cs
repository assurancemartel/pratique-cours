﻿using System;
public class Statistique
{
    static int donnerMinTab(int[] tableau)
    {
        int min = tableau.Min();
        return min;
    }
    static int donnerMaxTab(int[] tableau)
    {
        int max = tableau.Max();
        return max;

    }
    //tester le code
    public static void Main()
    {
        Console.WriteLine(donnerMinTab(new int[] { 9, 7, 1, 5 }));
        Console.WriteLine(donnerMaxTab(new int[] { 100, -100, 1, 50 }));
    }

}

