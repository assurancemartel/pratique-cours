﻿using System;
class Factorielle
{
    static void Main()
    {
        Console.WriteLine("Entrer un nombre entier pour avoir son foctoriel: ");
        int chiffre = int.Parse(Console.ReadLine());
        int resultat = calculerFactoriel(chiffre);
        Console.WriteLine("Le factoriel de  " + chiffre + "est : " + resultat);

    }
    static int calculerFactoriel(int chiffre)
    {
        int factoriel = 1;
        for (int i= 1; i<= chiffre; i++)
        {
            factoriel = factoriel * i;
        }
        return factoriel;


    }
}
