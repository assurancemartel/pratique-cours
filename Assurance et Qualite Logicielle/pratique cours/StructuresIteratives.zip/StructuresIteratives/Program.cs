﻿using System;
public static class StructuresIteratives
{
    public static void Main()
    {
        int compteur;
        for ( compteur  = 0; compteur<= 10; compteur++)
        {
            Console.WriteLine(compteur);
        }
        string[] tableauPrenom = { "Rayan", "Martel", "Brenda", "Manel", "Celine", "Mamadou" };
        for (int i=0; i<tableauPrenom.Length; i++)
        {
            Console.WriteLine(tableauPrenom[i]);
        }
        foreach(string prenom in tableauPrenom)
        {
            Console.WriteLine(prenom);
        }
        int j = 0;
        while (j < 5)
        {
            Console.WriteLine(j);
            j++;
        }
        int k = 0;
        do
        {
            Console.WriteLine(j);
            k++;

        } while (k < 4);
    }
}
