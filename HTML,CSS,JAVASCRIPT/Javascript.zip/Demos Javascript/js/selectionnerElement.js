function selectionnerParSelector(){
    /*Sélectionne le premier paragraphe du document et change son texte avec la
    *propriété textContent que nous étudierons plus tard dans cette partie*/
    let mon_paragraphe = document.querySelector('p');
    mon_paragraphe.textContent = '1er paragraphe du document';
    
    let documentDiv = document.querySelector('div'); //1er div du document
    //Sélectionne le premier paragraphe du premier div du document et modifie son texte
    documentDiv.querySelector('p').textContent = '1er paragraphe du premier div';

    /*Sélectionne le premier paragraphe du document avec un attribut class='bleu'
    *et change sa couleur en bleu avec la propriété style que nous étudierons
    *plus tard dans cette partie*/
    document.querySelector('p.bleu').style.color = 'blue';

    //Sélectionne tous les paragraphes du document
    let documentParagraphes = document.querySelectorAll('p');

    /*On utilise forEach() sur notre objet NodeList documentParas pour rajouter du
    *texte dans chaque paragraphe de notre document*/
    documentParagraphes.forEach(function(para, i){
        para.textContent += ' (paragraphe n°:' + (i +1) + ')';
        /*paragraphe.textContent = paragraphe.textContent + ' (paragraphe n°:' + index + ')';*/

    });


}

function selectionnerParId(){
    document.getElementById('p1').style.color = 'red';
}

function selectionnerParClasse(){
    //Sélectionne les éléments avec une class = 'bleu'
    let bleus = document.getElementsByClassName('bleu');

    //"bleu" est un objet de HTMLCollection qu'on va manipuler comme un tableau
    for(elmt of bleus){
        elmt.style.color = 'blue';
    }
}

function selectionnerParIdentite(){
    //Sélectionne tous les éléments p du document
    let paras = document.getElementsByTagName('p');

    //"paras" est un objet de HTMLCollection qu'on va manipuler comme un tableau
    for(para of paras){
        para.style.color = 'green';
    }
}