function appliquerStyle(){
    // Exemple 1: Boucles sur les éléments d'un tableau
    // Le tableau contient tous les <div> de notre page et on modifie leur couleur de 
    // fond avec le texte dans le <div> dans la boucle for
    let elements = document.querySelectorAll('div');
    

    for(let i = 0 ; i < elements.length ; i++){
        elements[i].style.backgroundColor = elements[i].innerText;
        //i = 0    elements[0] = 1ere div  div.style.backgroundcolor = "blue"
    }
}

function ajouterElements(){
    let listeEpicerie = ['Lait', 'Oeuf',  'Steak', 'Brocoli', 'Pain'];
    const listeHTML = document.getElementById('liste');

        // Exemple 1: Ajouter des éléments à la fin du tableau
        listeEpicerie.push('Fromage');

        // Exemple 2: Ajouter des éléments au début du tableau
        listeEpicerie.unshift('Céréales');

        // Exemple 3: Ajouter des éléments à un index spécifique du tableau
        // Le 1er paramètre indique l'index où ajouter
        // Le 2ème paramètre doit être 0, sinon des valeurs seront supprimées
        // Le 3ème paramètre indique l'élément à ajouter
        listeEpicerie.splice(listeEpicerie.length, 0, 'Tomate');
        


    //Vider la liste
    listeHTML.innerHTML ="";
    for(let i = 0 ; i < listeEpicerie.length ; i++){
        listeHTML.innerHTML += ('<li>' + listeEpicerie[i] + '</li>');
    }
}

function supprimerElements(){
let listeEpicerie = ['Lait', 'Oeuf', 'Steak', 'Brocoli', 'Pain'];
const listeHTML = document.getElementById('liste');

// Exemple 1: Supprimer des éléments à la fin du tableau
//listeEpicerie.pop();

// Exemple 2: Supprimer des éléments au début du tableau
//listeEpicerie.shift();

// Exemple 3: Supprimer des éléments à un index spécifique du tableau
// Le 1er paramètre indique l'index à supprimer
// Le 2ème paramètre indique le nombre de valeurs à supprimer
listeEpicerie.splice(2, 3);

//Vider la liste
listeHTML.innerHTML ="";
for(let i = 0 ; i < listeEpicerie.length ; i++){
        listeHTML.innerHTML += ('<li>' + listeEpicerie[i] + '</li>');
    }
}

function exercice(){
    let eleves = ["Driss", "John", "Sarah", "Mamadou"];
    let notes = ["03", "9", "8", "11"];

    eleves.unshift("karim");
    notes.unshift("05");

    eleves.splice(3,0,"Anna");
    notes.splice(3,0,"20");


    eleves.splice(2,1);
    notes.splice(2,1);

    
}




