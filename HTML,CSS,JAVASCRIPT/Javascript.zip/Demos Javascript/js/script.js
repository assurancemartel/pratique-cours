console.log("commande executée au lancement");

function direBonjour(){
    alert("Bonjour tout le monde");
    console.log("Fonction executée");
    return true;
}


function direBonjourPerso(){
    let nom = prompt("Saisissez votre nom", "Mr X");
    if (nom == null){
        nom = "inconnu";
    }
    alert("Bonjour "+nom);
}

//definir une fonction qui prend deux valeurs a et b
//et retourne la valeur suivante a² + b²

function sommecarre(a, b){
    let a_carre = carre(a);
    let b_carre = carre(b);
    let somme = a_carre + b_carre;
    return somme;
}

function carre(a){
    return a*a;
}


