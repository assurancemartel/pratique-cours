function ajouterParagraphe(){
    //Récupérer le noeud du template
    let myTemplate = document.getElementById("temp_para");

    //Cloner le noeud du template
    let clone_para = myTemplate.content.cloneNode("true");
    let texte_node = document.createTextNode("Nouveau contenu")
    clone_para.appendChild(texte_node);

    //Récupérer le noeud parent
    let monDiv = document.getElementById("monDiv");
    
    //Ajouter le clone au parent
    monDiv.appendChild(clone_para);
}
