function remplirChamps(){
        /*"pierre" est une variable qui contient un objet. Par abus de langage,
    *on dira que notre variable EST un objet*/
    
        let etudiant = {
        //nom, age et mail sont des propriétés de l'objet "pierre"
        nom : "Mohamed",
        age : 33,
        mail : "pierre.giraud@gamil.com",
        
        //Bonjour est une méthode de l'objet pierre
        bonjour: function(){
            alert('Bonjour, je suis ' + this.nom +
             ', j\'ai ' + this.age + ' ans');
        }
    };

    /*On accède aux propriétés "nom" et "age" de "pierre" et on affiche leur valeur
    *dans nos deux paragraphes p id='p1' et p id='p2'.
    *A noter : "document" est en fait aussi un objet, getElementById() une méthode
    *et innerHTML une propriété de l'API "DOM"!*/
    document.getElementById('p1').innerHTML += etudiant.nom;
    document.getElementById('p2').innerHTML += etudiant.age;

    //On modifie la valeur de la propriété "age" de "pierre"
    etudiant.age = 30;    

    document.getElementById('p3').innerHTML += etudiant.age;

    /*On accède à la méthode "bonjour" de l'objet "pierre" qu'on exécute de la même
    *même façon qu'une fonction anonyme stockée dans une variable*/

    etudiant.bonjour();
    
}

function ajouterInfos(){

    let pierre = {
        nom : "Pierre",
        age : 29,
        mail : "pierre.giraud@edhec.com",
        
        //Bonjour est une méthode de l'objet pierre
        bonjour: function(){
            alert('Bonjour, je suis ' + this.nom + ', j\'ai ' + this.age + ' ans');
        }
    };



    console.log("Avant mise à jour")
    console.log(pierre)
    
    pierre.taille = 170;
    console.log("Après mise à jour")
    console.log(pierre.taille);
    console.log(pierre);

    pierre.prez = function(){
        alert("Bonjour, je m'appelle "+pierre.nom+", je mesure "+pierre.taille);
    }

    //pierre.prez();
    document.getElementById('information').innerHTML += "Taille "+pierre.taille;

}