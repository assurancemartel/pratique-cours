function ajouterElement(){
    let text = document.getElementById("monTexte");

    const para = document.createElement("p"); //<p></p>
    const p_texte = document.createTextNode(text.value);// "Bonjour"
    para.appendChild(p_texte); //<p>Bonjour</p>

    const maDiv = document.getElementById("maDiv"); //<div id="maDiv"></div>
    maDiv.appendChild(para); //<div id="maDiv"><p>Bonjour</p></div>
    
}

function placerElement(){
    let text = document.getElementById("monTexte");

    const nouveau = document.createElement("p");
    const p_texte = document.createTextNode(text.value);
    nouveau.appendChild(p_texte);//<p>Bonjour</p>

    const parent = document.getElementById("autreDiv");
    const repere = document.getElementById("p2");
    parent.insertBefore(nouveau,repere);
}

function supprimerElement(){
    const elmnt = document.getElementById("p2");
    elmnt.remove();
}