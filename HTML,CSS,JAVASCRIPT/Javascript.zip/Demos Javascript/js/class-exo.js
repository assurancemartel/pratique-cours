class Etudiant2{
    constructor(nom, prenom, age){
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.inscrit = false;
        this.math = 0;
        this.francais = 0;
        this.philo = 0;
    }
    inscrire(frais){
        if (frais >= 500){
            this.inscrit = true;
        } else {
            console.log("Frais insffisant")
        }
        return this.inscrit;
    }

    noter(math, francais, philo){
        if(this.inscrit){
            this.math = math;
            this.francais = francais;
            this.philo = philo;
        } else{
            console.log("L'étudiant ne peut pas être noté.")
        }
    }

    evaluer(){
        if(this.inscrit){
            let somme = this.math + this.francais + this.philo
            return somme/3;
        } else{
            console.log("L'étudiant ne peut pas être noté.")
        }
        
    }
}

// Amélioration : créer objet notes pour les matieres