class Animal{
    constructor(n, p, c){
        this.nom = n;
        this.poids = p;
        this.crie = c;
        console.log("Animal créé");
    }
    crier(){
        alert("cet animal est : "+this.nom+" il "+this.crie)
    }
    grossir(poids){
        if (poids == null) {
            alert("renseigner le poids")
        } else{
            this.poids += poids;
        }
        console.log("Le nouveau poids est: "+this.poids);
    }
}

class Etudiant{
    constructor(nom, prenom, age){
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.inscrit = false;
        this.notes_ob={
            math : {exam1 : 15,
                    exam2 : 5        
            },
            fr : 20,
            phy : 2
        };

        //this.notes_ob.math = 0;
        //this.notes_ob.fr = 0;
        //this.notes_ob.phy = 0;


    }

    inscrire(montant){
        if(montant>500){
            this.inscrit = true;
        }
        return this.inscrit;
    }

    noter(m, f, p){
        if(this.inscrit){
            this.n_m = m;
            this.n_f = f;
            this.n_p = p;
        }else{
            console.log("non inscrit");
        }

    }

    evaluer(){
        if(this.inscrit){
            let moyenne = (this.n_f + this.n_m + this.n_p)/3;
            if(moyenne >= 10){
                console.log("reussi"+moyenne);
            }
            else("echoué");
        }else{
            console.log("non inscrit");
        }
    }
}