package com.collegelacite.evaluation_sommative_02_2718241


import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Log
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private val TAG =  "TransitionsEtatsTAG"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.i(TAG, "onCreate a été invoquée");
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart a été invoquée")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume a été invoquée")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause a été invoquée")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop a été invoquée")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart a été invoquée")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy a été invoquée")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstanceState")
        val textBox: EditText = findViewById(R.id.editTextText3)
        //Sauvegarde de l'état du widget EditText = Sauvegarde du userText qui est le texte saisi par l'utilisateur pou le nom
        val userText = textBox.text
        outState.putCharSequence("savedText", userText)


    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.i(TAG, "onRestoreInstanceState")
        val textBox: EditText = findViewById(R.id.editTextText3)
        //Récupèration de  l'état sauvegardé auparavant du widget EditText: champ de saisie du nom
        val userText = savedInstanceState.getCharSequence("savedText")
        textBox.setText(userText)
    }
}

