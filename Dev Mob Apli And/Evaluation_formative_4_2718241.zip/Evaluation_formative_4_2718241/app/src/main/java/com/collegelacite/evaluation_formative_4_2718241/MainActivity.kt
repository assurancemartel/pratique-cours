package com.collegelacite.evaluation_formative_4_2718241

// MainActivity.kt
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialiser les EditText et le bouton
        val editText1 = findViewById<EditText>(R.id.Nom2)
        val editText2 = findViewById<EditText>(R.id.Addresse2)
        val editText3 = findViewById<EditText>(R.id.Phone3)
        val editText4 = findViewById<EditText>(R.id.EmailAddress2)
        val clearButton = findViewById<Button>(R.id.button4)

        // Ajouter un écouteur d'événements au bouton
        clearButton.setOnClickListener {
            editText1.text.clear()
            editText2.text.clear()
            editText3.text.clear()
            editText4.text.clear()
        }
    }
}
